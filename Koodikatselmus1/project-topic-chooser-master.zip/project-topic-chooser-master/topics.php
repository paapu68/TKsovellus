<?php
  require_once 'lib/common.php';
  require_once 'lib/models/topic.php';
  showView("topics" );
