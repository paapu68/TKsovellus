DROP TABLE coursestoaccounts;
DROP TABLE project;
DROP TABLE topic;
DROP TABLE course;
DROP TABLE account;
