<?php
  require_once 'lib/common.php';
  showView("showtopic");
