<?php
  require_once 'lib/common.php';
  require_once "lib/databaseconnection.php";

  showView("login", 3);
