<h1>New Course</h1>
<form>
  <div class='field'>
    <label>Course Name</label>
    <input class="form-control" placeholder="Course Name" type="text" />
  </div>
  <div class='actions'>
    <p><input class="btn btn-default" value="Create Course" /></p>
  </div>
</form>
