<h1>Edit Topic</h1>
<form>
  <div class='field'>
    <label>Name</label>
    <input class="form-control" placeholder="Name" type="text" />
  </div>
  <div class='field'>
    <label>Description</label>
    <input class="form-control" placeholder="Description" type="text" />
  </div>
  <div class='actions'>
    <p><input class="btn btn-default" value="Edit topic" /></p>
  </div>
</form>
