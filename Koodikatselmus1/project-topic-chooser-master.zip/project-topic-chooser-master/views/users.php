<h1> Users </h1>
<p><a href="newuser.php" class="btn btn-sm btn-default"> New User </a></p>
<table class = "table table-hover">
  <tr>
    <th> Name </th>
    <th> Type </th>
    <th> </th>
    <th> </th>
  </tr>
  <tbody>
  </tbody>
</table>
