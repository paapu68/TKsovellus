<h1>New User</h1>
<form>
<div class='field'>
  <label>Name</label>
  <input class="form-control" placeholder="Name" type="text" />
</div>
<div class='field'>
  <label>Password</label>
  <input class="form-control" placeholder="Password" type="password" />
</div>
<div class='field'>
  <label>Password confirmation</label>
  <input class="form-control" placeholder="Password confirmation" type="password" />
</div>
<input type="checkbox"> <label>Administrator</label>
<div class='actions'>
  <p><input class="btn btn-default" value="Create User" /></p>
</div>
