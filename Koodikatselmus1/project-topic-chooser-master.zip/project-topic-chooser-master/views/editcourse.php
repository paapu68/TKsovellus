<h1>Edit Course</h1>
<form>
  <div class='field'>
    <label>Course Name</label>
    <input class="form-control" placeholder="Course Name" type="text" />
  </div>
  <div class='actions'>
    <p><input class="btn btn-default" value="Update Course" /></p>
  </div>
</form>
