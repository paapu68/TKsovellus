<h1>Edit Project</h1>
<form>
    <label>Student Name</label>
    <input class="form-control" placeholder="Student Name" type="text" />
    <label>Hours</label>
    <input class="form-control" placeholder="Hours" type="text" />
    <label>Grade</label>
    <input class="form-control" placeholder="Grade" type="text" />
  <div class='actions'>
    <input class="btn btn-default" value="Update Project" />
  </div>
</form>
